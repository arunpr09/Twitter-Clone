# Twitter Clone

The clone version of `Twitter`.

## [Live View](https://twitter-clone-eb901.web.app/)
Click the link to view my live site : [https://twitter-clone-eb901.web.app/](https://twitter-clone-eb901.web.app/)

### `List of technologies`

`ReactJs`, `NodeJs`, `ExpressJs`, `MongoDB`, `Firebase`, `Material UI`.


### `About this project `
The `Twitter Clone` project is build with a team for learning purpose. Where the key goal was learning to build a professional application.