import React from 'react'
import '../pages.css'

function Lists() {
    return (
        <div className='page'>
            <h2 className='pageTitle'>Welcome to Lists page</h2>
        </div>
    )
}

export default Lists